*** A2 Part 2 ***
Name: Ang Yang
Student Number: 42567644
login ID: y2m1b@ugrad.cs.ubc.ca

Made hands rotate with head when W and S are pressed

*** A2 Part 1 ***
Name: Ang Yang
Student Number: 42567644
login ID: y2m1b@ugrad.cs.ubc.ca
